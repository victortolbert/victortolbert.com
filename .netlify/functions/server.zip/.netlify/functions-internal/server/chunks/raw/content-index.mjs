// ROLLUP_NO_REPLACE 
 const contentIndex = "{\"/\":[\"content:index.json\"]}";

export { contentIndex as default };
//# sourceMappingURL=content-index.mjs.map
