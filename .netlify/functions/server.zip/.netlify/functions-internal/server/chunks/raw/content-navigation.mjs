// ROLLUP_NO_REPLACE 
 const contentNavigation = "[{\"title\":\"\",\"_path\":\"/\"}]";

export { contentNavigation as default };
//# sourceMappingURL=content-navigation.mjs.map
