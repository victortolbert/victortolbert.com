const IconCSS_vue_vue_type_style_index_0_scoped_b0a27896_lang = "span[data-v-b0a27896]{background-color:currentColor;display:inline-block;-webkit-mask-image:var(--14c66e23);mask-image:var(--14c66e23);-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-size:100% 100%;mask-size:100% 100%;vertical-align:middle}";

const IconCSSStyles_918e129e = [IconCSS_vue_vue_type_style_index_0_scoped_b0a27896_lang, IconCSS_vue_vue_type_style_index_0_scoped_b0a27896_lang];

export { IconCSSStyles_918e129e as default };
//# sourceMappingURL=IconCSS-styles.918e129e.mjs.map
