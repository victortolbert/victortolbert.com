const IconCSS_vue_vue_type_style_index_0_scoped_0d49e9f3_lang = "span[data-v-0d49e9f3]{background-color:currentColor;display:inline-block;-webkit-mask-image:var(--3f918f06);mask-image:var(--3f918f06);-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-size:100% 100%;mask-size:100% 100%;vertical-align:middle}";

const IconCSSStyles_9RfX8AL0 = [IconCSS_vue_vue_type_style_index_0_scoped_0d49e9f3_lang, IconCSS_vue_vue_type_style_index_0_scoped_0d49e9f3_lang];

export { IconCSSStyles_9RfX8AL0 as default };
//# sourceMappingURL=IconCSS-styles.9RfX8AL0.mjs.map
