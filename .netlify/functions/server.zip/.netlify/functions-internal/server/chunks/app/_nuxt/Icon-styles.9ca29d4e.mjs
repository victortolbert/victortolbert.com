const Icon_vue_vue_type_style_index_0_scoped_e88dff66_lang = ".icon[data-v-e88dff66]{display:inline-block;vertical-align:middle}";

const IconStyles_9ca29d4e = [Icon_vue_vue_type_style_index_0_scoped_e88dff66_lang, Icon_vue_vue_type_style_index_0_scoped_e88dff66_lang];

export { IconStyles_9ca29d4e as default };
//# sourceMappingURL=Icon-styles.9ca29d4e.mjs.map
