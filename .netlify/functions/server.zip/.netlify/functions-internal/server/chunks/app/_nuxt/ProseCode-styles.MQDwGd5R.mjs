const ProseCode_vue_vue_type_style_index_0_lang = "pre code .line{display:block;min-height:1rem}";

const ProseCodeStyles_MQDwGd5R = [ProseCode_vue_vue_type_style_index_0_lang];

export { ProseCodeStyles_MQDwGd5R as default };
//# sourceMappingURL=ProseCode-styles.MQDwGd5R.mjs.map
