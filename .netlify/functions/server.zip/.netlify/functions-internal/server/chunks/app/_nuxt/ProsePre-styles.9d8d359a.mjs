const ProsePre_vue_vue_type_style_index_0_lang = "pre code .line{display:block;min-height:1rem}";

const ProsePreStyles_9d8d359a = [ProsePre_vue_vue_type_style_index_0_lang, ProsePre_vue_vue_type_style_index_0_lang];

export { ProsePreStyles_9d8d359a as default };
//# sourceMappingURL=ProsePre-styles.9d8d359a.mjs.map
