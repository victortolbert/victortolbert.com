const ProsePre_vue_vue_type_style_index_0_lang = "pre code .line{display:block;min-height:1rem}";

const ProsePreStyles_nulVsdP = [ProsePre_vue_vue_type_style_index_0_lang, ProsePre_vue_vue_type_style_index_0_lang];

export { ProsePreStyles_nulVsdP as default };
//# sourceMappingURL=ProsePre-styles.nul-VsdP.mjs.map
