const ProseCode_vue_vue_type_style_index_0_lang = "pre code .line{display:block;min-height:1rem}";

const ProseCodeStyles_93005832 = [ProseCode_vue_vue_type_style_index_0_lang];

export { ProseCodeStyles_93005832 as default };
//# sourceMappingURL=ProseCode-styles.93005832.mjs.map
